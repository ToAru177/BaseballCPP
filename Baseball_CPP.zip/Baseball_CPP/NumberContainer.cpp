#include "NumberContainer.h"



NumberContainer::NumberContainer()
{
}


NumberContainer::~NumberContainer()
{
}
