#pragma once
class Constant
{
private:
	
public:

	const int Max_Value = 9;
	const int Digit = 3;

};

