#include "Guess.h"



Guess::Guess()
{
}


Guess::~Guess()
{
}
