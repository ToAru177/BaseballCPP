#include "Answer.h"



Answer::Answer()
{
}


Answer::~Answer()
{
}
